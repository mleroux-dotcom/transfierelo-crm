@echo off
rem Publica el CRM en internet (Railway). Doble clic y sigue las instrucciones.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\publicar.ps1"
pause
